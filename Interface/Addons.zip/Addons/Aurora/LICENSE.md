Copyright (c) 2010-2021 [Haleth/Lightsword](http://www.wowinterface.com/forums/member.php?u=110142), [Gethe](http://www.wowinterface.com/forums/member.php?u=111611). All rights reserved.

The contents of this software (the "AddOn"), excluding third-party resources,
fall under the aforementioned copyright. The author(s) of this AddOn hereby
grant the following permissions:

* Permission to use, read or otherwise interpret this AddOn for personal use,
  without restrictions.

* Permission to include this AddOn with other works not derived from this
  AddOn for the purpose of creating "user interface compilations" or "addon
  packs" for the "World of Warcraft" game client and to distribute such
  collective works on websites operated by Curse, Inc or Good Game Mods, LLC
  (including curse.com, curseforge.com, wowace.com and wowinterface.com) as
  long as the AddOn is distributed intact and unmodified.

* This AddOn may not be redistributed by itself or in any other way, in whole
  or in part, modified or unmodified, without specific prior written
  permission from the author(s) of this AddOn.

* The names of this AddOn and/or its author(s) may not be used to promote or
  endorse works derived from this AddOn without specific prior written
  permission from the author(s) of this AddOn.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHOR(S) OR COPYRIGHT HOLDER(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
