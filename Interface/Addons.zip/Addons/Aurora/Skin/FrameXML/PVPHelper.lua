local _, private = ...
if not private.isBCC then return end

--[[ Lua Globals ]]
-- luacheck: globals

--[[ Core ]]
--local Aurora = private.Aurora
--local Base, Hook, Skin = Aurora.Base, Aurora.Hook, Aurora.Skin

--do --[[ FrameXML\PVPHelper.lua ]]
--end

--do --[[ FrameXML\PVPHelper.xml ]]
--end

function private.FrameXML.PVPHelper()
    --[[ PVPFramePopup ]]--
end
