# Advanced Interface Options

## [1.6.0](https://github.com/Stanzilla/AdvancedInterfaceOptions/tree/1.6.0) (2021-06-29)
[Full Changelog](https://github.com/Stanzilla/AdvancedInterfaceOptions/compare/1.5.0...1.6.0) [Previous Releases](https://github.com/Stanzilla/AdvancedInterfaceOptions/releases)

- Update TOC for Patch 9.1  
- Fixed FCT text labels in classic/bcc (#46)  
- Forgot retail sanity check (#45)  
- Overwrite cameraDistanceMaxZoomFactor (Fixes #42, #43) (#44)  
- CI: fix classic packages  
- CI: Push BCC version to CF as well  